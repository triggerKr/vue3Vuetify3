package com.example.tibrv;

import com.tibco.tibrv.*;
import org.springframework.stereotype.Service;

import java.util.UUID;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.TimeUnit;

@Service
public class TibrvService {

    public String sendAndReceive(String message) throws Exception {
        Tibrv.open(Tibrv.IMPL_NATIVE);
        TibrvTransport transport = new TibrvRvdTransport();
        String replySubject = "subject.reply." + UUID.randomUUID();
        BlockingQueue<String> responseQueue = new ArrayBlockingQueue<>(1);

        TibrvListener listener = new TibrvListener(
            Tibrv.defaultQueue(),
            new TibrvResponseCallback(responseQueue),
            transport,
            replySubject,
            null
        );

        TibrvMsg requestMsg = new TibrvMsg();
        requestMsg.setSendSubject("subject.req");
        requestMsg.setReplySubject(replySubject);
        requestMsg.addString("data", message);
        transport.send(requestMsg);

        String response = responseQueue.poll(5, TimeUnit.SECONDS);
        listener.destroy();
        Tibrv.close();
        return (response != null) ? response : "응답 없음 (Timeout)";
    }
}