package com.example.tibrv;

import com.tibco.tibrv.*;

import java.util.concurrent.BlockingQueue;

public class TibrvResponseCallback implements TibrvMsgCallback {

    private final BlockingQueue<String> queue;

    public TibrvResponseCallback(BlockingQueue<String> queue) {
        this.queue = queue;
    }

    @Override
    public void onMsg(TibrvListener listener, TibrvMsg msg) {
        try {
            String result = msg.getField("result").data.toString();
            queue.offer(result);
        } catch (TibrvException e) {
            e.printStackTrace();
            queue.offer("응답 처리 중 오류 발생");
        }
    }
}